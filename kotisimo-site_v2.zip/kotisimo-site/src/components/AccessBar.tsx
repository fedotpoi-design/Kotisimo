import { useEffect, useRef, useState } from "react";
import { FAIRY_TALE } from "@/lib/content";

type Size = "m" | "l" | "xl";
type Prefs = { size: Size; contrast: boolean; readable: boolean; motionOff: boolean };
const DEFAULT: Prefs = { size: "m", contrast: false, readable: false, motionOff: false };
const KEY = "kotissimo-a11y";

export function speak(text: string, onEnd?: () => void) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return false;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "ru-RU";
  u.rate = 0.9;
  const ru = window.speechSynthesis.getVoices().find((v) => v.lang.startsWith("ru"));
  if (ru) u.voice = ru;
  if (onEnd) u.onend = onEnd;
  window.speechSynthesis.speak(u);
  return true;
}

export function AccessBar() {
  const [p, setP] = useState<Prefs>(DEFAULT);
  const [open, setOpen] = useState(false);
  const [playing, setPlaying] = useState<"off" | "on" | "paused">("off");
  const loaded = useRef(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(KEY);
      if (saved) setP({ ...DEFAULT, ...JSON.parse(saved) });
    } catch {}
    loaded.current = true;
    return () => window.speechSynthesis?.cancel();
  }, []);

  useEffect(() => {
    const h = document.documentElement;
    h.dataset["size"] = p.size;
    h.dataset["contrast"] = p.contrast ? "high" : "normal";
    h.dataset["readable"] = p.readable ? "on" : "off";
    h.dataset["motion"] = p.motionOff ? "off" : "on";
    if (loaded.current) localStorage.setItem(KEY, JSON.stringify(p));
  }, [p]);

  const toggleBook = () => {
    const s = window.speechSynthesis;
    if (!s) return alert("Ваш браузер не умеет читать вслух.");
    if (playing === "on") { s.pause(); setPlaying("paused"); return; }
    if (playing === "paused") { s.resume(); setPlaying("on"); return; }
    if (speak(FAIRY_TALE, () => setPlaying("off"))) setPlaying("on");
  };
  const stopBook = () => { window.speechSynthesis?.cancel(); setPlaying("off"); };

  const btn = "min-h-11 rounded-full border-2 border-foreground/20 px-3 text-sm font-bold transition-colors hover:bg-secondary aria-pressed:bg-primary aria-pressed:text-primary-foreground aria-pressed:border-primary";

  return (
    <div role="region" aria-label="Настройки доступности" className="flex flex-wrap items-center gap-2">
      <button className={`${btn} lg:hidden`} aria-expanded={open} aria-controls="a11y-more" onClick={() => setOpen(!open)}>
        {open ? "✕ Скрыть" : "👁 Доступность"}
      </button>
      <button className={`${btn} bg-accent text-accent-foreground border-accent`} onClick={toggleBook} aria-pressed={playing !== "off"}>
        {playing === "on" ? "⏸ Пауза" : playing === "paused" ? "▶ Дальше" : "🎧 Аудиосказка"}
      </button>
      {playing !== "off" && (
        <button className={btn} onClick={stopBook}>⏹ Стоп</button>
      )}
      <div id="a11y-more" className={`${open ? "flex" : "hidden"} w-full flex-wrap items-center gap-2 lg:flex lg:w-auto`}>
      <div role="group" aria-label="Размер шрифта" className="flex items-center gap-1">
        {(["m", "l", "xl"] as Size[]).map((s, i) => (
          <button
            key={s}
            className={`${btn} min-w-11`}
            aria-pressed={p.size === s}
            aria-label={["Обычный шрифт", "Крупный шрифт", "Очень крупный шрифт"][i]}
            onClick={() => setP({ ...p, size: s })}
            style={{ fontSize: `${0.85 + i * 0.25}rem` }}
          >
            А
          </button>
        ))}
      </div>
      <button className={btn} aria-pressed={p.contrast} onClick={() => setP({ ...p, contrast: !p.contrast })}>◐ Контраст</button>
      <button className={btn} aria-pressed={p.readable} onClick={() => setP({ ...p, readable: !p.readable })}>Аа Лёгкое чтение</button>
      <button className={btn} aria-pressed={p.motionOff} onClick={() => setP({ ...p, motionOff: !p.motionOff })}>⏸ Без движения</button>
      </div>
    </div>
  );
}

export function ListenButton({ text }: { text: string }) {
  return (
    <button
      onClick={() => speak(text)}
      className="inline-flex min-h-11 items-center gap-2 rounded-full border-2 border-current px-4 text-sm font-bold opacity-90 hover:opacity-100"
      aria-label="Прочитать этот блок вслух"
    >
      🔊 Прочитать вслух
    </button>
  );
}
