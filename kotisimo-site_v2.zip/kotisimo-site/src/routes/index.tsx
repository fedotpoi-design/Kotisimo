import { createFileRoute } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";
import catBed from "@/assets/cat-bed.jpg";
import { AccessBar, ListenButton } from "@/components/AccessBar";
import { ABOUT, DISCOUNTS, DO, PRICES, PROMOS, RULES, STATS } from "@/lib/content";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Котиссимо — котокафе и приют для котиков в Москве" },
      { name: "description", content: "Котокафе Котиссимо: 50 спасённых котиков, чай и уют. Аудиосказка, крупный шрифт и простые тексты." },
      { property: "og:title", content: "Котиссимо — котокафе и приют" },
      { property: "og:description", content: "Спасаем котиков с улицы и ищем им дом. Приходите в гости!" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Section({ id, title, listen, children, className = "" }: { id: string; title: string; listen: string; children: React.ReactNode; className?: string }) {
  return (
    <section id={id} aria-labelledby={`${id}-h`} className={`px-4 py-10 sm:py-16 ${className}`}>
      <div className="mx-auto max-w-5xl">
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <h2 id={`${id}-h`} className="text-3xl font-bold sm:text-4xl">{title}</h2>
          <ListenButton text={`${title}. ${listen}`} />
        </div>
        {children}
      </div>
    </section>
  );
}

const NAV = [["about", "О нас"], ["rules", "Правила"], ["prices", "Цены"], ["promo", "Скидки"], ["visit", "Как прийти"]];

function Index() {
  return (
    <>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-full focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground">
        Перейти к содержанию
      </a>
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-2 sm:py-3 lg:flex-row lg:items-center lg:justify-between">
          <a href="#main" className="flex items-center gap-2 text-2xl font-bold" style={{ fontFamily: "var(--font-heading)" }}>
            <span aria-hidden>🐾</span> Котиссимо
          </a>
          <AccessBar />
        </div>
        <nav aria-label="Разделы сайта" className="mx-auto max-w-6xl overflow-x-auto px-4 pb-2">
          <ul className="flex gap-1 whitespace-nowrap">
            {NAV.map(([id, t]) => (
              <li key={id}><a href={`#${id}`} className="inline-flex min-h-11 items-center whitespace-nowrap rounded-full px-3 font-semibold underline-offset-4 hover:bg-secondary hover:underline">{t}</a></li>
            ))}
          </ul>
        </nav>
      </header>

      <main id="main">
        <section className="relative isolate overflow-hidden">
          <img src={hero} alt="Котики отдыхают в уютном котокафе" width={1600} height={912} className="absolute inset-0 -z-10 size-full object-cover" />
          <div className="absolute inset-0 -z-10 bg-dark-panel/70" />
          <div className="mx-auto max-w-3xl animate-float-in px-4 py-16 text-center sm:py-28 text-dark-panel-foreground">
            <h1 className="text-4xl font-bold break-words sm:text-5xl md:text-6xl">Добро пожаловать в Котиссимо!</h1>
            <p className="mt-6 text-lg sm:text-xl">Мы спасаем котиков с улицы. Приходите к ним в гости. Может, вы найдёте друга.</p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <a href="#visit" className="inline-flex min-h-12 items-center rounded-full bg-accent px-6 font-bold text-accent-foreground">Забронировать время</a>
              <a href="#prices" className="inline-flex min-h-12 items-center rounded-full border-2 border-current px-6 font-bold">Узнать цены</a>
            </div>
          </div>
        </section>

        <Section id="about" title="О нас" listen={ABOUT.join(" ") + " " + DO.join(" ")}>
          <div className="grid gap-8 md:grid-cols-2">
            <div>
              <ul className="space-y-3 text-lg">
                {ABOUT.map((t) => <li key={t} className="flex gap-3"><span aria-hidden>🐈</span>{t}</li>)}
              </ul>
              <h3 className="mt-8 text-2xl font-bold">Что можно делать?</h3>
              <ul className="mt-3 space-y-2 text-lg">
                {DO.map((t) => <li key={t} className="flex gap-3"><span aria-hidden>✔️</span>{t}</li>)}
              </ul>
            </div>
            <img src={catBed} alt="Полосатый котик спит в пушистой лежанке с игрушкой" width={1024} height={800} loading="lazy" className="w-full rounded-2xl object-cover" />
          </div>
        </Section>

        <section aria-label="Цифры" className="panel mx-4 rounded-3xl px-4 py-12 md:mx-auto md:max-w-5xl">
          <ul className="grid gap-8 text-center md:grid-cols-3">
            {STATS.map((s) => (
              <li key={s.n}><p className="text-4xl font-bold sm:text-5xl" style={{ fontFamily: "var(--font-heading)" }}>{s.n}</p><p className="mt-2 text-lg">{s.t}</p></li>
            ))}
          </ul>
          <p className="mt-8 text-center text-lg">Мы не просто кафе. Мы — приют для котиков без дома.</p>
        </section>

        <Section id="rules" title="Правила" listen={RULES.map((r) => r.t).join(" ")} className="bg-secondary mt-16">
          <ol className="grid gap-4 md:grid-cols-3">
            {RULES.map((r, i) => (
              <li key={r.t} className="panel flex gap-4 p-5 sm:p-6 text-lg">
                <span aria-hidden className="text-4xl">{r.i}</span>
                <span><span className="sr-only">Правило {i + 1}. </span>{r.t}</span>
              </li>
            ))}
          </ol>
        </Section>

        <Section id="prices" title="Цены" listen={PRICES.map((p) => `${p.t}: ${p.p}.`).join(" ") + " Платите только за минуты. Больше 1400 рублей не платите."}>
          <div className="panel max-w-xl p-5 sm:p-8">
            <p className="text-xl font-bold">Цена за одного гостя</p>
            <dl className="mt-4 divide-y divide-dark-panel-foreground/20 text-lg">
              {PRICES.map((p) => (
                <div key={p.t} className="flex justify-between gap-4 py-3"><dt>{p.t}</dt><dd className="font-bold">{p.p}</dd></div>
              ))}
            </dl>
            <p className="mt-4">⏱ Платите только за минуты, которые были у нас.</p>
            <p className="mt-2">💰 Больше <b>1400 ₽</b> не платите.</p>
          </div>
        </Section>

        <Section id="promo" title="Скидки" listen={DISCOUNTS.map((d) => `${d.t}: ${d.p}.`).join(" ") + " " + PROMOS.map((p) => `${p.t}. ${p.d}`).join(" ")} className="bg-secondary">
          <div className="grid gap-6 md:grid-cols-2">
            <div className="panel p-5 sm:p-8">
              <h3 className="text-2xl font-bold">Кому скидка</h3>
              <dl className="mt-4 divide-y divide-dark-panel-foreground/20 text-lg">
                {DISCOUNTS.map((d) => (
                  <div key={d.t} className="flex justify-between gap-4 py-3"><dt>{d.t}</dt><dd className="font-bold">{d.p}</dd></div>
                ))}
              </dl>
              <p className="mt-6">⚠️ Не оставляйте ребёнка одного. Скидки не для шумных групп.</p>
            </div>
            <ul className="panel space-y-5 p-5 sm:p-8">
              <li><h3 className="text-2xl font-bold">Акции</h3></li>
              {PROMOS.map((p) => (
                <li key={p.t}><p className="text-lg font-bold">{p.t}</p><p>{p.d}</p></li>
              ))}
            </ul>
          </div>
        </Section>

        <Section id="visit" title="Как прийти" listen="Адрес: Москва, Новая Басманная, дом 31. Метро Красные Ворота, Бауманская, Комсомольская. Идти 10–15 минут. Мы открыты каждый день с 12 до 21 часа.">
          <ul className="grid gap-4 text-lg md:grid-cols-3">
            <li className="rounded-2xl border-2 border-border p-6"><span aria-hidden className="text-3xl">📍</span><p className="mt-2 font-bold">Адрес</p><p>Москва, Новая Басманная, 31</p></li>
            <li className="rounded-2xl border-2 border-border p-6"><span aria-hidden className="text-3xl">🚇</span><p className="mt-2 font-bold">Метро</p><p>Красные Ворота, Бауманская, Комсомольская. 10–15 минут пешком.</p></li>
            <li className="rounded-2xl border-2 border-border p-6"><span aria-hidden className="text-3xl">🕛</span><p className="mt-2 font-bold">Время</p><p>Каждый день, 12:00–21:00</p></li>
          </ul>
        </Section>
      </main>

      <footer className="panel rounded-none px-4 py-10 text-center">
        <p className="text-2xl font-bold" style={{ fontFamily: "var(--font-heading)" }}>🐾 Котиссимо</p>
        <p className="mt-2">Котокафе и приют для котиков. Ждём вас каждый день!</p>
      </footer>
    </>
  );
}
